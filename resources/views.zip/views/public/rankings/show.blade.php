@extends('layouts.public')

@section('title', $system->name)

@section('content')
<div class="pub-rank">

    <div class="pub-rank__head">
        <div class="pub-rank__eyebrow">Ranking @if($system->owner_label) · {{ $system->owner_label }}@endif</div>
        <h1 class="pub-rank__title">{{ $system->name }}</h1>
        <div class="pub-rank__sub">
            @if(($activeLabel ?? 'General') === 'General')
            Puntos acumulados de todos los torneos
            @else
            {{ $activeLabel }}
            @endif
        </div>
    </div>

    @if($categories->isNotEmpty())
    <div class="rk-cats rk-cats--public">
        @php $mk = fn($p) => route('public.rankings.show', array_merge([$system], $p)); @endphp
        <a href="{{ $mk(['cat' => 'all']) }}" class="rk-cat {{ ($activeCat ?? 'all') === 'all' ? 'is-active' : '' }}">General</a>
        @foreach($categories as $c)
        <a href="{{ $mk(['cat' => $c['key']]) }}" class="rk-cat {{ ($activeCat ?? '') === $c['key'] ? 'is-active' : '' }}">{{ $c['label'] }}</a>
        @endforeach
        @if($categories->count() > 1)
        <a href="{{ $mk(['view' => 'summary']) }}" class="rk-cat rk-cat--summary">Resumen</a>
        @endif
    </div>
    @endif

    @if($board->isEmpty())
    <div class="pub-rank__empty">Esta tabla todavía no tiene puntos.</div>
    @else
    <div class="pub-rank__list">
        @foreach($board as $row)
        <div class="pub-rank__row {{ $row['rank'] <= 3 ? 'pub-rank__row--podium' : '' }}">
            <div class="pub-rank__pos">
                @if($row['rank'] === 1) 🥇
                @elseif($row['rank'] === 2) 🥈
                @elseif($row['rank'] === 3) 🥉
                @else <span class="pub-rank__num">{{ $row['rank'] }}</span>
                @endif
            </div>
            <div class="pub-rank__name">{{ $row['name'] }}</div>
            <div class="pub-rank__pts">{{ number_format($row['points']) }}<span class="pub-rank__pts-label">pts</span></div>
        </div>
        @endforeach
    </div>
    @endif

</div>
@endsection