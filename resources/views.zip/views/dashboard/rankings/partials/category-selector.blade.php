{{--
    Category selector for the leaderboard. Renders chips: General (combined),
    one per category, and a "Resumen" link to the stacked summary.

    Expects:
      $system      — RankingSystem
      $categories  — Collection [{key,label,players}]
      $activeCat   — 'all' | category_key (current selection)
      $routeName   — 'ranking-systems.leaderboard' | 'public.rankings.show'
--}}
@php
    $mk = fn($params) => route($routeName, array_merge([$system], $params));
@endphp

<div class="rk-cats">
    <a href="{{ $mk(['cat' => 'all']) }}"
       class="rk-cat {{ ($activeCat ?? 'all') === 'all' ? 'is-active' : '' }}">General</a>

    @foreach($categories as $c)
        <a href="{{ $mk(['cat' => $c['key']]) }}"
           class="rk-cat {{ ($activeCat ?? '') === $c['key'] ? 'is-active' : '' }}">
            {{ $c['label'] }}
            <span class="rk-cat__count">{{ $c['players'] }}</span>
        </a>
    @endforeach

    @if($categories->count() > 1)
        <a href="{{ $mk(['view' => 'summary']) }}" class="rk-cat rk-cat--summary">
            <i class="fa-solid fa-layer-group"></i> Resumen
        </a>
    @endif
</div>
