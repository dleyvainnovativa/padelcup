{{-- resources/views/layouts/public.blade.php
     Player-facing shell: no sidebar, no admin nav. Used for the landing page,
     public tournament pages, search, legal pages, self-service payment, and
     quick-register. data-theme is server-rendered from the cookie. --}}
<!DOCTYPE html>
<html lang="es-MX" data-theme="{{ request()->cookie('tc_theme', 'light') }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', 'Voleo') · Voleo</title>

    {{-- Open Graph / Twitter cards. Pages override og-title/og-description/
         og-image via @section; defaults keep every public page shareable. --}}
    @php $ogDesc = 'Gestión de torneos de pádel: inscripciones, grupos, llaves, calendario y resultados en vivo.'; @endphp
    <meta property="og:site_name" content="Voleo">
    <meta property="og:type" content="@yield('og-type', 'website')">
    <meta property="og:title" content="@yield('og-title', 'Voleo')">
    <meta property="og:description" content="@yield('og-description', $ogDesc)">
    <meta property="og:url" content="{{ url()->current() }}">
    <meta property="og:image" content="@yield('og-image', asset('img/og-default.png'))">
    <meta property="og:image:width" content="1200">
    <meta property="og:image:height" content="630">
    <meta property="og:image:alt" content="@yield('og-title', 'Voleo')">
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="@yield('og-title', 'Voleo')">
    <meta name="twitter:description" content="@yield('og-description', $ogDesc)">
    <meta name="twitter:image" content="@yield('og-image', asset('img/og-default.png'))">
    <meta name="description" content="@yield('og-description', $ogDesc)">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="icon" type="image/png" href="{{asset('img/icons/favicon-96x96.png')}}" sizes="96x96" />
    <link rel="icon" type="image/svg+xml" href="{{asset('img/icons/favicon.svg')}}" />
    <link rel="shortcut icon" href="{{asset('img/icons/favicon.ico')}}" />
    <link rel="apple-touch-icon" sizes="180x180" href="{{asset('img/icons/apple-touch-icon.png')}}" />
    <meta name="apple-mobile-web-app-title" content="Voleo" />
    <link rel="manifest" href="{{asset('img/icons/site.webmanifest')}}" />
    <script defer src="https://cloud.umami.is/script.js" data-website-id="{{ env('UMAMI_ID') }}"></script>
    @vite(['resources/css/app.css','resources/css/public.css', 'resources/css/share.css', 'resources/js/app.js'])
    @stack('head')
</head>

<body>
    <div class="public-shell @yield('shell_class')">
        <header class="ph" data-ph>
            <div class="ph__inner">
                <a href="/" class="public-brand">
                    <x-logo :height="26" />
                </a>

                {{-- Desktop nav --}}
                <nav class="ph__nav">
                    <a href="{{ route('public.directory') }}" class="ph__link">Torneos</a>
                    <a href="{{ route('public.circuits.index') }}" class="ph__link">Circuitos</a>
                    <a href="{{ route('public.search') }}" class="ph__link">Buscar</a>
                    <a href="{{ route('docs.index') }}" class="ph__link">Guías</a>
                    <a href="{{ route('dashboard') }}" class="ph__cta">Soy organizador</a>
                </nav>

                {{-- Always-visible actions (theme toggle + mobile hamburger) --}}
                <div class="ph__actions">
                    <button class="ph__theme icon-btn" data-theme-toggle aria-label="Cambiar tema" title="Cambiar tema">
                        <i class="fa-solid fa-moon"></i>
                    </button>
                    <button class="ph__burger" data-ph-open aria-label="Abrir menú" aria-expanded="false">
                        <span></span><span></span><span></span>
                    </button>
                </div>
            </div>
        </header>

        {{-- Offcanvas (mobile) --}}
        <div class="ph-oc" data-ph-oc aria-hidden="true">
            <div class="ph-oc__backdrop" data-ph-close></div>
            <aside class="ph-oc__panel" role="dialog" aria-modal="true" aria-label="Menú">
                <div class="ph-oc__head">
                    <a href="/" class="public-brand">
                        <x-logo :height="26" />
                    </a>
                    <button class="ph-oc__close" data-ph-close aria-label="Cerrar menú"><i class="fa-solid fa-xmark"></i></button>
                </div>
                <nav class="ph-oc__nav">
                    <a href="{{ route('public.directory') }}" class="ph-oc__link"><i class="fa-solid fa-trophy"></i> Torneos</a>
                    <a href="{{ route('public.circuits.index') }}" class="ph-oc__link"><i class="fa-solid fa-ranking-star"></i> Circuitos</a>
                    <a href="{{ route('public.search') }}" class="ph-oc__link"><i class="fa-solid fa-magnifying-glass"></i> Buscar</a>
                    <a href="{{ route('docs.index') }}" class="ph-oc__link"><i class="fa-solid fa-book"></i> Guías</a>
                    <a href="{{ route('dashboard') }}" class="ph-oc__cta">Soy organizador</a>
                </nav>

                <div class="ph-oc__foot">
                    <div class="ph-oc__social">
                        <a href="https://instagram.com/voleo.mx" target="_blank" rel="noopener" aria-label="Instagram"><i class="fa-brands fa-instagram"></i></a>
                        <a href="https://facebook.com/voleo.mx" target="_blank" rel="noopener" aria-label="Facebook"><i class="fa-brands fa-facebook-f"></i></a>
                        <a href="https://tiktok.com/@voleo.mx" target="_blank" rel="noopener" aria-label="TikTok"><i class="fa-brands fa-tiktok"></i></a>
                        <a href="mailto:contacto@voleo.mx" aria-label="Correo"><i class="fa-solid fa-envelope"></i></a>
                    </div>
                    <div class="ph-oc__legal">
                        <a href="{{ route('legal.terminos') }}">Términos</a>
                        <a href="{{ route('legal.privacidad') }}">Privacidad</a>
                        <a href="{{ route('legal.aviso') }}">Aviso de Privacidad</a>
                        <a href="{{ route('legal.reembolsos') }}">Reembolsos</a>
                    </div>
                    <p class="ph-oc__meta">© {{ date('Y') }} Voleo · Veracruz, México</p>
                </div>
            </aside>
        </div>

        <main class="public-main">
            @if(session('status'))
            <div class="pub-flash pub-flash--ok">{{ session('status') }}</div>
            @endif
            @if($errors->any())
            <div class="pub-flash pub-flash--err">
                @foreach($errors->all() as $e)<div>{{ $e }}</div>@endforeach
            </div>
            @endif
            @yield('content')
        </main>

        <footer class="pf">
            <div class="pf__inner">
                <div class="pf__brand-col">
                    <a href="/" class="public-brand pb-4">
                        <x-logo :height="26" />
                    </a>
                    <p class="pf__tagline">Organiza torneos de pádel sin el caos: inscripciones, llaves, calendario y resultados en vivo.</p>
                </div>
                <div class="pf__col">
                    <h4>Plataforma</h4>
                    <a href="{{ route('public.directory') }}">Torneos</a>
                    <a href="{{ route('public.circuits.index') }}">Circuitos</a>
                    <a href="{{ route('public.search') }}">Buscar</a>
                    <a href="{{ route('docs.index') }}">Guías</a>
                    <a href="{{ route('dashboard') }}">Soy organizador</a>
                </div>
                <div class="pf__col">
                    <h4>Legal</h4>
                    <a href="{{ route('legal.terminos') }}">Términos</a>
                    <a href="{{ route('legal.privacidad') }}">Privacidad</a>
                    <a href="{{ route('legal.aviso') }}">Aviso de Privacidad</a>
                    <a href="{{ route('legal.reembolsos') }}">Reembolsos</a>
                </div>
                <div class="pf__col">
                    <h4>Contacto</h4>
                    <a href="mailto:contacto@voleo.mx">contacto@voleo.mx</a>
                </div>
            </div>
            <div class="pf__bottom">
                <span class="pf__copy">© {{ date('Y') }} Voleo. Todos los derechos reservados.</span>
                <span class="pf__made">Desarrollado por <a href="https://innovativa.mx">Innovativa</a></span>
            </div>
        </footer>
    </div>
    <script>
        (function() {
            var oc = document.querySelector('[data-ph-oc]');
            var openBtn = document.querySelector('[data-ph-open]');
            if (!oc || !openBtn) return;
            var closeEls = oc.querySelectorAll('[data-ph-close]');

            function open() {
                oc.classList.add('is-open');
                oc.setAttribute('aria-hidden', 'false');
                openBtn.setAttribute('aria-expanded', 'true');
                document.body.style.overflow = 'hidden';
            }

            function close() {
                oc.classList.remove('is-open');
                oc.setAttribute('aria-hidden', 'true');
                openBtn.setAttribute('aria-expanded', 'false');
                document.body.style.overflow = '';
            }

            openBtn.addEventListener('click', open);
            closeEls.forEach(function(el) {
                el.addEventListener('click', close);
            });
            // Close when a nav link is tapped (but not the theme toggle).
            oc.querySelectorAll('.ph-oc__panel a[href]').forEach(function(a) {
                a.addEventListener('click', close);
            });
            document.addEventListener('keydown', function(e) {
                if (e.key === 'Escape' && oc.classList.contains('is-open')) close();
            });

            // Sticky header: add a class once scrolled, for the blur/shadow.
            var header = document.querySelector('[data-ph]');
            if (header) {
                var onScroll = function() {
                    header.classList.toggle('is-scrolled', window.scrollY > 8);
                };
                onScroll();
                window.addEventListener('scroll', onScroll, {
                    passive: true
                });
            }
        })();
    </script>
</body>

</html>