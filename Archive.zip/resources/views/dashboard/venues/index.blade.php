@extends('layouts.app')

@section('title', 'Sedes y canchas')

@section('content')
<x-breadcrumb :items="[
        ['label' => 'Torneos', 'url' => route('tournaments.index')],
        ['label' => $tournament->name, 'url' => route('tournaments.show', $tournament)],
        ['label' => 'Sedes y canchas'],
    ]" />

<div class="page-head">
    <div>
        <h1>Sedes y canchas</h1>
        <div class="page-sub">{{ $tournament->name }}</div>
    </div>
    <a href="{{ route('schedule.index', $tournament) }}" class="btn btn-soft"><i class="fa-solid fa-calendar-days me-1"></i> Ir al calendario</a>
</div>

@include('dashboard.partials.flash')
@if($errors->any())
<div class="alert py-2 px-3 mb-3" style="font-size:13px;border-radius:var(--radius);background:var(--danger-soft);color:var(--danger-text);">
    @foreach($errors->all() as $e)<div>{{ $e }}</div>@endforeach
</div>
@endif

<div class="alert py-2 px-3 mb-3" style="font-size:13px;border-radius:var(--radius);background:var(--bg-subtle);color:var(--text-muted);">
    <i class="fa-solid fa-circle-info me-1"></i>
    Cada cancha se crea con la ventana de juego del torneo
    ({{ \Illuminate\Support\Str::of($tournament->play_start)->substr(0,5) }}–{{ \Illuminate\Support\Str::of($tournament->play_end)->substr(0,5) }},
    partidos de {{ $tournament->match_duration_minutes }} min). Puedes agregar ventanas
    personalizadas por cancha y día abajo (p. ej. una cancha libre solo de 18:00 a 22:00 el viernes).
    <a href="{{ route('tournaments.edit', $tournament) }}">Cambiar ajustes</a>.
    <form method="POST" action="{{ route('availability.resync', $tournament) }}" class="d-inline"
        data-confirm="Esto reemplaza TODAS las ventanas (incluidas las personalizadas) por la ventana del torneo. ¿Continuar?"
        data-confirm-title="Actualizar horarios" data-confirm-ok="Actualizar">
        @csrf
        <button class="btn btn-soft btn-sm ms-2">Restablecer al horario del torneo</button>
    </form>
</div>

<div class="tc-card mb-3">
    <div class="tc-card__body">
        <form method="POST" action="{{ route('venues.store', $tournament) }}" class="d-flex gap-2 flex-wrap align-items-end">
            @csrf
            <div>
                <label class="form-label" style="font-size:12px;">Nueva sede</label>
                <input type="text" name="name" placeholder="Nombre de la sede" required class="form-control" style="border-radius:var(--radius);">
            </div>
            <div style="flex:1;min-width:180px;">
                <label class="form-label" style="font-size:12px;">Dirección (opcional)</label>
                <input type="text" name="address" class="form-control" style="border-radius:var(--radius);">
            </div>
            <button class="btn btn-accent">Agregar sede</button>
        </form>
    </div>
</div>

@forelse($tournament->venues as $venue)
<div data-venues-root>
    <div class="tc-card mb-3">
        <div class="tc-card__head" style="display:flex;align-items:center;justify-content:space-between;gap:10px;">
            <div style="min-width:0;">
                <h3 style="margin:0;">{{ $venue->name }}</h3>
                <span style="font-size:12px;color:var(--text-faint);">{{ $venue->address }}</span>
            </div>
            @php
            $vCourts = $venue->courts->count();
            $vSched = (int) (($scheduledByVenue[$venue->id] ?? 0));
            $warn = "¿Eliminar la sede «{$venue->name}»?";
            if ($vCourts > 0) $warn .= " Se eliminarán sus {$vCourts} " . ($vCourts === 1 ? 'cancha' : 'canchas') . " y sus horarios.";
            if ($vSched > 0) $warn .= " {$vSched} " . ($vSched === 1 ? 'partido programado quedará' : 'partidos programados quedarán') . " sin cancha asignada.";
            $warn .= " Esta acción no se puede deshacer.";
            @endphp
            <form method="POST" action="{{ route('venues.destroy', [$tournament, $venue]) }}"
                data-confirm="{{ $warn }}"
                data-confirm-title="Eliminar sede"
                data-confirm-variant="danger"
                data-confirm-ok="Eliminar sede">
                @csrf @method('DELETE')
                <button class="btn btn-soft btn-sm court-icon-btn court-icon-btn--danger"
                    title="Eliminar sede" aria-label="Eliminar sede">
                    <i class="fa-solid fa-trash"></i>
                </button>
            </form>
        </div>
        <div class="tc-card__body">
            @php
            $playDays = collect($tournament->playDays());
            $dayFmt = fn($d) => \Illuminate\Support\Str::ucfirst($d->locale('es')->isoFormat('ddd D MMM'));
            @endphp

            @forelse($venue->courts as $court)
            <div class="court-block" data-court-block
                data-bulk-delete-url="{{ route('availability.bulkDestroy', [$tournament, $court]) }}"
                data-update-tpl="{{ route('availability.update', [$tournament, '__ID__']) }}">
                <div class="court-block__head">
                    <form method="POST" action="{{ route('courts.update', [$tournament, $court]) }}"
                        class="court-rename" data-court-rename>
                        @csrf @method('PATCH')
                        <input type="text" name="name" value="{{ $court->name }}" maxlength="255"
                            class="court-rename__input" aria-label="Nombre de la cancha">
                        <button type="submit" class="court-rename__save" title="Guardar nombre"><i class="fa-solid fa-check"></i></button>
                    </form>

                    <div class="court-block__actions">
                        {{-- Select mode toggle (multi-delete). --}}
                        <button type="button" class="btn btn-soft btn-sm court-icon-btn"
                            data-select-toggle aria-pressed="false"
                            title="Seleccionar horarios" aria-label="Seleccionar horarios">
                            <i class="fa-solid fa-square-check"></i>
                        </button>

                        <form method="POST" action="{{ route('courts.duplicate', [$tournament, $court]) }}" class="d-inline">
                            @csrf
                            <button class="btn btn-soft btn-sm court-icon-btn" title="Duplicar cancha con sus horarios" aria-label="Duplicar cancha">
                                <i class="fa-solid fa-copy"></i>
                            </button>
                        </form>

                        <form method="POST" action="{{ route('courts.destroy', [$tournament, $court]) }}"
                            data-confirm="¿Eliminar «{{ $court->name }}»? Se quitará del calendario."
                            data-confirm-title="Eliminar cancha" data-confirm-variant="danger" data-confirm-ok="Eliminar">
                            @csrf @method('DELETE')
                            <button class="btn btn-soft btn-sm court-icon-btn court-icon-btn--danger" title="Eliminar cancha" aria-label="Eliminar cancha">
                                <i class="fa-solid fa-trash"></i>
                            </button>
                        </form>
                    </div>
                </div>

                {{-- Bulk action bar (shown only in select mode) --}}
                <div class="court-bulk-bar" data-bulk-bar hidden>
                    <span class="court-bulk-bar__info"><span data-bulk-count>0</span> seleccionados</span>
                    <button type="button" class="btn btn-sm court-bulk-bar__delete" data-bulk-delete disabled>
                        <i class="fa-solid fa-trash me-1"></i> Eliminar
                    </button>
                </div>

                {{-- Current windows grouped by day --}}
                @php
                $byDay = $court->availabilities
                ->sortBy('starts_at')
                ->groupBy(fn($w) => $w->starts_at->timezone('America/Mexico_City')->format('Y-m-d'));
                @endphp
                @if($byDay->isEmpty())
                <div style="font-size:12px;color:var(--text-faint);margin:6px 0;">Sin horarios. Usa la ventana del torneo o agrega ventanas personalizadas abajo.</div>
                @else
                <div class="court-wins">
                    @foreach($byDay as $ymd => $wins)
                    @php $d = \Carbon\Carbon::parse($ymd, 'America/Mexico_City'); @endphp
                    <div class="court-win-day">
                        <span class="court-win-day__label">{{ \Illuminate\Support\Str::ucfirst($d->locale('es')->isoFormat('ddd D MMM')) }}</span>
                        <div class="court-win-tags">
                            @foreach($wins as $w)
                            @php
                            $st = $w->starts_at->timezone('America/Mexico_City');
                            $en = $w->ends_at->timezone('America/Mexico_City');
                            @endphp
                            <span class="court-win-tag" data-win-tag
                                data-win-id="{{ $w->id }}"
                                data-win-start="{{ $st->format('H:i') }}"
                                data-win-end="{{ $en->format('H:i') }}"
                                title="Editar horario">
                                <span class="court-win-tag__label">{{ $st->format('H:i') }}–{{ $en->format('H:i') }}</span>
                                <form method="POST" action="{{ route('availability.destroy', [$tournament, $w]) }}" class="d-inline" data-win-x>
                                    @csrf @method('DELETE')
                                    <button class="court-win-tag__x" title="Quitar" aria-label="Quitar horario">×</button>
                                </form>
                            </span>
                            @endforeach
                        </div>
                    </div>
                    @endforeach
                </div>
                @endif

                {{-- Add custom window --}}
                <form method="POST" action="{{ route('availability.store', [$tournament, $court]) }}" class="court-win-add">
                    @csrf
                    <select name="day" required class="form-select form-select-sm" style="width:auto;border-radius:var(--radius);">
                        <option value="">Día…</option>
                        @foreach($playDays as $d)
                        <option value="{{ $d->format('Y-m-d') }}">{{ $dayFmt($d) }}</option>
                        @endforeach
                    </select>
                    <input type="time" name="start_time" required class="form-control form-control-sm" style="width:auto;border-radius:var(--radius);">
                    <span style="color:var(--text-faint);">→</span>
                    <input type="time" name="end_time" required class="form-control form-control-sm" style="width:auto;border-radius:var(--radius);">
                    <button class="btn btn-soft btn-sm"><i class="fa-solid fa-plus me-1"></i> Agregar ventana</button>
                </form>
            </div>
            @empty
            <div style="font-size:13px;color:var(--text-muted);margin-bottom:10px;">Esta sede no tiene canchas todavía.</div>
            @endforelse

            <div class="court-add-row">
                <form method="POST" action="{{ route('courts.store', [$tournament, $venue]) }}" class="d-flex gap-2 align-items-end">
                    @csrf
                    <div>
                        <label class="form-label" style="font-size:12px;">Nueva cancha</label>
                        <input type="text" name="name" placeholder="Cancha 1" required class="form-control form-control-sm" style="border-radius:var(--radius);">
                    </div>
                    <button class="btn btn-soft btn-sm">Agregar cancha</button>
                </form>

                <span class="court-add-sep">o</span>

                <form method="POST" action="{{ route('courts.generate', [$tournament, $venue]) }}" class="d-flex gap-2 align-items-end">
                    @csrf
                    <div>
                        <label class="form-label" style="font-size:12px;">Generar varias</label>
                        <input type="number" name="count" min="1" max="20" value="4" required class="form-control form-control-sm" style="width:80px;border-radius:var(--radius);">
                    </div>
                    <button class="btn btn-soft btn-sm"><i class="fa-solid fa-wand-magic-sparkles me-1"></i> Generar canchas</button>
                </form>
            </div>
        </div>
    </div>
</div>
@empty
<div class="tc-card">
    <div class="tc-card__body" style="color:var(--text-muted);">
        Aún no hay sedes. Agrega una para empezar a definir canchas.
    </div>
</div>
@endforelse
<script>
    (function() {
        // Inline court rename: save via AJAX so the page doesn't reload. The save
        // button only "lights up" when the name changed; Enter submits too.
        document.querySelectorAll('[data-court-rename]').forEach(function(form) {
            var input = form.querySelector('.court-rename__input');
            var original = input.value;

            function dirty() {
                return input.value.trim() !== original && input.value.trim() !== '';
            }

            function reflect() {
                form.classList.toggle('is-dirty', dirty());
            }
            input.addEventListener('input', reflect);

            form.addEventListener('submit', function(e) {
                e.preventDefault();
                if (!dirty()) return;
                var btn = form.querySelector('.court-rename__save');
                btn.disabled = true;
                fetch(form.action, {
                    method: 'PATCH',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}',
                        'X-Requested-With': 'XMLHttpRequest'
                    },
                    body: JSON.stringify({
                        name: input.value.trim()
                    }),
                }).then(function(r) {
                    if (!r.ok) throw new Error();
                    return r.json();
                }).then(function(data) {
                    original = data.name || input.value.trim();
                    input.value = original;
                    form.classList.remove('is-dirty');
                    btn.disabled = false;
                    btn.classList.add('is-ok');
                    setTimeout(function() {
                        btn.classList.remove('is-ok');
                    }, 1000);
                }).catch(function() {
                    btn.disabled = false;
                    // Fallback: submit normally so the manager still gets the rename.
                    form.submit();
                });
            });
        });
    })();
</script>
@endsection