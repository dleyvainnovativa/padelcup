<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Storage;

class Sponsor extends Model
{
    protected $fillable = [
        'tournament_id',
        'name',
        'image_path',
        'link_url',
        'sort_order',
        'is_active',
        'is_admin',
        'scope',
    ];

    protected function casts(): array
    {
        return ['is_active' => 'boolean', 'is_admin' => 'boolean'];
    }

    public function tournament()
    {
        return $this->belongsTo(Tournament::class);
    }

    public function imageUrl(): ?string
    {
        if (blank($this->image_path)) return null;
        return Storage::disk(config('filesystems.default'))->url($this->image_path);
    }

    public function isGlobal(): bool
    {
        return $this->scope === 'global';
    }

    /**
     * Active sponsors to show on a tournament's public page: the tournament's
     * own sponsors (manager-created) + admin sponsors for it + admin GLOBAL
     * sponsors. Ordered. (Admin globals can be opted out via the same
     * hide_global_ads flag if you want; here they always show unless inactive.)
     */
    public static function forTournament(Tournament $tournament): \Illuminate\Support\Collection
    {
        return static::query()
            ->where('is_active', true)
            ->where(function ($q) use ($tournament) {
                // This tournament's sponsors (manager or admin, scope=tournament).
                $q->where('tournament_id', $tournament->id)
                    // OR admin global sponsors.
                    ->orWhere(fn($q) => $q->where('is_admin', true)->where('scope', 'global'));
            })
            ->orderBy('sort_order')->orderBy('id')
            ->get();
    }
}
