<?php

namespace App\Models;

use App\Enums\MatchResultType;
use App\Enums\MatchState;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class GameMatch extends Model
{
    use HasFactory;

    protected $fillable = [
        'category_id',
        'group_id',
        'pair_a_id',
        'pair_b_id',
        'seed_label_a',
        'seed_label_b',
        'round',
        'slot',
        'feeder_a_id',
        'feeder_b_id',
        'feeder_a_source',
        'feeder_b_source',
        'is_third_place',
        'court_id',
        'starts_at',
        'duration_minutes',
        'state',
        'result_type',
        'sets',
        'winner_pair_id',
        'incident_note',
        'proposed_by',
        'confirmed_by',
        'confirmed_at',
    ];

    protected function casts(): array
    {
        return [
            'sets' => 'array',
            'is_third_place' => 'boolean',
            'starts_at' => 'datetime',
            'confirmed_at' => 'datetime',
            'state' => MatchState::class,
            'result_type' => MatchResultType::class,
        ];
    }

    public function category()
    {
        return $this->belongsTo(Category::class);
    }
    public function group()
    {
        return $this->belongsTo(Group::class);
    }
    public function pairA()
    {
        return $this->belongsTo(Pair::class, 'pair_a_id');
    }
    public function pairB()
    {
        return $this->belongsTo(Pair::class, 'pair_b_id');
    }
    public function winner()
    {
        return $this->belongsTo(Pair::class, 'winner_pair_id');
    }

    /** The losing pair id of a decided match (null if undecided). */
    public function loserPairId(): ?int
    {
        if (! $this->winner_pair_id) return null;
        return $this->winner_pair_id === $this->pair_a_id ? $this->pair_b_id : $this->pair_a_id;
    }
    public function court()
    {
        return $this->belongsTo(Court::class);
    }
    public function feederA()
    {
        return $this->belongsTo(GameMatch::class, 'feeder_a_id');
    }
    public function feederB()
    {
        return $this->belongsTo(GameMatch::class, 'feeder_b_id');
    }

    /**
     * Human label for a side of the match, used on the schedule board. Returns
     * the pair name when known, otherwise a descriptor of where it comes from
     * (e.g. "Ganador P1·P2" for a Mexicano R2 feeder slot not yet resolved).
     */
    /**
     * DISPLAY-ONLY "ghost" qualifier name for a side, if this side is still an
     * unbound seed label (e.g. "A1") AND that group has finished. $map comes from
     * GhostQualifierResolver::mapFor() as [ seedLabel => pairName ]. Returns null
     * when the side is already a real pair, is a feeder, or the group isn't done.
     *
     * This never changes state — it only lets the bracket show who qualified from
     * a completed group without waiting for the whole category.
     */
    public function ghostFor(string $side, array $map): ?string
    {
        // Only ghost when there's no real pair and no feeder for this side.
        $pair = $side === 'a' ? $this->pairA : $this->pairB;
        if ($pair) return null;
        $feeder = $side === 'a' ? $this->feederA : $this->feederB;
        if ($feeder) return null;

        $label = $side === 'a' ? $this->seed_label_a : $this->seed_label_b;
        if (! $label || $label === 'BYE') return null;

        return $map[$label] ?? null;
    }

    /**
     * Like ghostFor(), but takes a tournament-wide [category_id => map] array and
     * picks this match's category. For tournament-spanning views (public calendar,
     * dashboard board) that render matches from many categories at once.
     */
    public function ghostForIn(string $side, array $mapsByCategory): ?string
    {
        $map = $mapsByCategory[$this->category_id] ?? null;
        if (! $map) return null;
        return $this->ghostFor($side, $map);
    }

    /**
     * The source-GROUP letter for a bracket side ("A", "B", …), for showing a
     * "Grupo A" tag. Works across states: a bound pair is looked up by pair_id;
     * an unbound seed label (incl. a ghost) is read from its label ("A1" → "A").
     * "Q" extra-qualifier labels return null until bound (then the pair lookup
     * gives the real group). $tags = GhostQualifierResolver::groupTagsFor().
     */
    public function groupTagFor(string $side, array $tags): ?string
    {
        $pairId = $side === 'a' ? $this->pair_a_id : $this->pair_b_id;
        if ($pairId && isset($tags['pairs'][$pairId])) {
            return $tags['pairs'][$pairId];
        }
        $label = $side === 'a' ? $this->seed_label_a : $this->seed_label_b;
        if ($label && isset($tags['labels'][$label])) {
            return $tags['labels'][$label];
        }
        return null;
    }

    /** Like groupTagFor(), but takes a tournament-wide [category_id => tags] map. */
    public function groupTagForIn(string $side, array $tagsByCategory): ?string
    {
        $tags = $tagsByCategory[$this->category_id] ?? null;
        if (! $tags) return null;
        return $this->groupTagFor($side, $tags);
    }

    public function sideLabel(string $side): string
    {
        $pair = $side === 'a' ? $this->pairA : $this->pairB;
        if ($pair) {
            return $pair->name();
        }

        $feeder = $side === 'a' ? $this->feederA : $this->feederB;
        $source = $side === 'a' ? $this->feeder_a_source : $this->feeder_b_source;
        if ($feeder) {
            $word = $source === 'loser' ? 'Perdedor' : 'Ganador';
            // Show the feeder match's pairs compactly if known.
            $fa = $feeder->pairA?->name();
            $fb = $feeder->pairB?->name();
            $of = ($fa && $fb) ? " ({$fa} / {$fb})" : '';
            return "{$word}{$of}";
        }

        // Positional seed label (e.g. "A1", "B2") before pairs are bound.
        $label = $side === 'a' ? $this->seed_label_a : $this->seed_label_b;
        if ($label) {
            return $label === 'BYE' ? 'Bye' : $this->seedLabelText($label);
        }

        return 'Por definir';
    }

    /** Turn "A1" into "Grupo A - 1", "Q1" into "Mejor tercero 1". */
    private function seedLabelText(string $label): string
    {
        if (preg_match('/^Q(\d+)$/', $label, $m)) {
            return "Mejor clasificado {$m[1]}";
        }
        if (preg_match('/^([A-Z])(\d+)$/', $label, $m)) {
            return "Grupo {$m[1]} - {$m[2]}";
        }
        return $label;
    }

    /**
     * Small badge for a GROUP match's play format:
     *   'MEX' → Mexicano (only applies to 4-pair groups)
     *   'RR'  → round-robin (3- and 5-pair groups, or non-Mexicano categories)
     *   null  → not a group match (bracket)
     *
     * Mirrors GroupGenerationService::rebuildGroupMatches(): the Mexicano format
     * is applied ONLY when the group has exactly 4 pairs; every other group size
     * plays round-robin regardless of the category setting.
     */
    public function groupFormatBadge(): ?string
    {
        if (! $this->group_id || ! $this->group) return null;

        $size = $this->group->relationLoaded('pairs')
            ? $this->group->pairs->count()
            : $this->group->pairs()->count();

        $isMexicano = $this->category?->group_format === \App\Enums\GroupFormat::Mexicano
            && $size === 4;

        return $isMexicano ? 'MEX' : 'RR';
    }

    /** Pairs in this match's group (0 for bracket matches). */
    public function groupSize(): int
    {
        if (! $this->group_id || ! $this->group) return 0;
        return $this->group->relationLoaded('pairs')
            ? $this->group->pairs->count()
            : $this->group->pairs()->count();
    }

    /** A grouping/context label: "Categoría · Grupo X · Ronda N". */
    public function contextLabel(): string
    {
        $parts = [];
        if ($this->category) $parts[] = $this->category->name;
        if ($this->group) $parts[] = $this->group->name;
        if ($this->round) {
            // Group matches: "R1/R2". Bracket matches (no group): F/SF/QF/...
            $parts[] = $this->group_id
                ? 'R' . $this->round
                : $this->bracketRoundAbbr();
        }
        return implode(' · ', $parts);
    }

    /**
     * Total rounds in this category's bracket (matches with no group).
     * Cached per category for the request to avoid N+1 on boards/lists.
     */
    public function bracketTotalRounds(): int
    {
        static $cache = [];
        $cid = $this->category_id;
        if (! array_key_exists($cid, $cache)) {
            $cache[$cid] = (int) static::where('category_id', $cid)
                ->whereNull('group_id')
                ->max('round');
        }
        return $cache[$cid];
    }

    /**
     * Abbreviated bracket round by distance from the final:
     *  0 → F, 1 → SF, 2 → QF, 3 → 8F, 4 → 16F, 5 → 32F ...
     */
    public function bracketRoundAbbr(): string
    {
        $total = $this->bracketTotalRounds();
        if ($total < 1 || ! $this->round) return 'R' . $this->round;

        $distance = $total - $this->round; // 0 = final
        return match ($distance) {
            0 => 'F',
            1 => 'SF',
            2 => 'QF',
            default => (2 ** $distance) . 'F', // 3 → 8F, 4 → 16F, 5 → 32F
        };
    }

    /** Full Spanish bracket round name (Final, Semifinal, Cuartos, Octavos...). */
    public function bracketRoundName(): string
    {
        $total = $this->bracketTotalRounds();
        if ($total < 1 || ! $this->round) return 'Ronda ' . $this->round;

        $distance = $total - $this->round;
        return match ($distance) {
            0 => 'Final',
            1 => 'Semifinal',
            2 => 'Cuartos de final',
            3 => 'Octavos de final',
            4 => 'Dieciseisavos',
            5 => 'Treintaidosavos',
            default => 'Ronda ' . $this->round,
        };
    }

    /**
     * Scheduling phase key for this match, used to match it to a phase window.
     * Group matches → 'groups'. Bracket matches → their round by distance from
     * the final: final / semifinal / quarterfinal / r16 / r32.
     */
    public function phaseKey(): string
    {
        if ($this->group_id) return 'groups';

        $total = $this->bracketTotalRounds();
        if ($total < 1 || ! $this->round) return 'groups';

        $distance = $total - $this->round;
        return match ($distance) {
            0 => 'final',
            1 => 'semifinal',
            2 => 'quarterfinal',
            3 => 'r16',
            4 => 'r32',
            default => 'r32',
        };
    }

    /**
     * Schedule status for board coloring:
     *  - 'played'    : has a confirmed result
     *  - 'playing'   : now is within the match's time window, no result yet
     *  - 'scheduled' : has a time but hasn't started / no result
     * Time-based (CDMX). Only meaningful once scheduled.
     */
    public function scheduleStatus(): string
    {
        if ($this->state === MatchState::Confirmed || $this->winner_pair_id) {
            return 'played';
        }
        if ($this->starts_at) {
            $start = $this->starts_at->copy();
            $end = $start->copy()->addMinutes((int) ($this->duration_minutes ?: 60));
            $now = now();
            if ($now->betweenIncluded($start, $end)) {
                return 'playing';
            }
        }
        return 'scheduled';
    }

    /** Both pairs known → results can be entered. */
    public function isReadyForResult(): bool
    {
        return (bool) ($this->pair_a_id && $this->pair_b_id);
    }

    public function isConfirmed(): bool
    {
        return $this->state === MatchState::Confirmed;
    }

    public function isReady(): bool
    {
        return $this->pair_a_id !== null && $this->pair_b_id !== null;
    }

    /**
     * Player-facing: can this user propose a score for this match?
     * True when the match has both pairs, isn't confirmed, has NO pending
     * proposal already, and one of the user's linked players is in either pair.
     */
    public function playerIdsForUser(\App\Models\User $user): array
    {
        return $user->players()->pluck('id')->all();
    }

    public function proposals()
    {
        return $this->hasMany(\App\Models\MatchProposal::class, 'game_match_id');
    }

    public function pendingProposal()
    {
        return $this->hasOne(\App\Models\MatchProposal::class, 'game_match_id')
            ->where('status', \App\Models\MatchProposal::PENDING)
            ->latest();
    }

    public function canBeProposedBy(?\App\Models\User $user): bool
    {
        if (! $user) return false;
        if (! $this->isReady()) return false;
        if ($this->isConfirmed()) return false;
        // One pending proposal at a time — hide the button while one is open.
        if ($this->pendingProposal()->exists()) return false;

        $mine = $this->playerIdsForUser($user);
        if (! $mine) return false;

        $inMatch = array_merge(
            $this->pairA ? array_filter([$this->pairA->player1_id, $this->pairA->player2_id]) : [],
            $this->pairB ? array_filter([$this->pairB->player1_id, $this->pairB->player2_id]) : [],
        );

        return (bool) array_intersect($mine, $inMatch);
    }

    /** All player ids involved (for player-level scheduling conflicts, Phase 7). */
    public function playerIds(): array
    {
        return array_merge(
            $this->pairA?->playerIds() ?? [],
            $this->pairB?->playerIds() ?? [],
        );
    }

    /** Sets won by each side from the sets array. Returns [aSets, bSets]. */
    public function setsWon(): array
    {
        $a = $b = 0;
        foreach ($this->sets ?? [] as $set) {
            [$ga, $gb] = [$set[0] ?? 0, $set[1] ?? 0];
            if ($ga > $gb) $a++;
            elseif ($gb > $ga) $b++;
        }
        return [$a, $b];
    }

    /** Games won by each side across all sets. Returns [aGames, bGames]. */
    public function gamesWon(): array
    {
        $a = $b = 0;
        foreach ($this->sets ?? [] as $set) {
            $a += $set[0] ?? 0;
            $b += $set[1] ?? 0;
        }
        return [$a, $b];
    }

    public function searchableNames(array $ghostMapsByCategory = []): string
    {
        $names = [];

        $pushPair = function ($pair) use (&$names) {
            if (! $pair) return;
            foreach ([$pair->player1 ?? null, $pair->player2 ?? null] as $pl) {
                if ($pl && filled($pl->name)) $names[] = \Illuminate\Support\Str::lower($pl->name);
            }
        };

        foreach (['a' => $this->pairA, 'b' => $this->pairB] as $side => $pair) {
            if ($pair) {
                // Bound side: real players.
                $pushPair($pair);
                continue;
            }

            // Unbound side — gather PROJECTED names.

            // 1) Feeder projection: the feeder match's two pairs' players.
            $feeder = $side === 'a' ? $this->feederA : $this->feederB;
            if ($feeder) {
                $pushPair($feeder->pairA ?? null);
                $pushPair($feeder->pairB ?? null);
            }

            // 2) Ghost qualifier: projected "Name / Name" string from the map.
            $ghost = $this->ghostForIn($side, $ghostMapsByCategory);
            if ($ghost) {
                // Split "Ana Gómez / Luis Pérez" into individual lowercased tokens.
                foreach (preg_split('/\s*\/\s*/', $ghost) as $part) {
                    if (filled($part)) $names[] = \Illuminate\Support\Str::lower(trim($part));
                }
            }
        }

        return implode('|', array_values(array_unique(array_filter($names))));
    }

    /**
     * True when at least one side is NOT a bound pair but IS projected (feeder or
     * ghost qualifier). Used to mark the card as "por confirmar" in search results.
     */
    public function isProjected(array $ghostMapsByCategory = []): bool
    {
        foreach (['a', 'b'] as $side) {
            $pair = $side === 'a' ? $this->pairA : $this->pairB;
            if ($pair) continue; // bound → not projected on this side

            $feeder = $side === 'a' ? $this->feederA : $this->feederB;
            if ($feeder) return true;

            if ($this->ghostForIn($side, $ghostMapsByCategory)) return true;
        }
        return false;
    }
}