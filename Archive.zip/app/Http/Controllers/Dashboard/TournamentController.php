<?php

namespace App\Http\Controllers\Dashboard;

use App\Http\Controllers\Controller;
use App\Http\Requests\Tournament\StoreTournamentRequest;
use App\Models\Tournament;
use Illuminate\Http\Request;

class TournamentController extends Controller
{
    public function index(Request $request)
    {
        $tournaments = Tournament::where('manager_id', $request->user()->id)
            ->withCount('categories')
            ->latest()
            ->paginate(12);

        return view('dashboard.tournaments.index', compact('tournaments'));
    }

    public function create()
    {
        $this->authorize('create', Tournament::class);

        return view('dashboard.tournaments.create');
    }

    public function store(StoreTournamentRequest $request)
    {
        $this->authorize('create', Tournament::class);

        $tournament = Tournament::create([
            ...$request->validated(),
            'manager_id' => $request->user()->id,
            'is_listed' => $request->boolean('is_listed'),
        ]);

        $this->syncRankingSystems($request, $tournament);

        return redirect()
            ->route('tournaments.show', $tournament)
            ->with('status', 'Torneo creado.');
    }

    public function show(Tournament $tournament)
    {
        $this->authorize('view', $tournament);

        $tournament->load(['categories' => fn($q) => $q->withCount([
            'pairs' => fn($p) => $p->whereHas('registration', fn($r) => $r->whereNotIn('status', [
                \App\Enums\RegistrationStatus::Cancelled->value,
                \App\Enums\RegistrationStatus::Withdrawn->value,
            ])),
        ])]);

        return view('dashboard.tournaments.show', compact('tournament'));
    }

    public function edit(Tournament $tournament)
    {
        $this->authorize('update', $tournament);

        $scheduledCount = \App\Models\GameMatch::whereHas('category', fn($q) => $q->where('tournament_id', $tournament->id))
            ->whereNotNull('starts_at')
            ->count();

        return view('dashboard.tournaments.edit', compact('tournament', 'scheduledCount'));
    }

    public function update(StoreTournamentRequest $request, Tournament $tournament)
    {
        $this->authorize('update', $tournament);

        // Detect whether scheduling-affecting fields changed (to know if we need
        // to re-derive availability and prune now-invalid placements).
        $schedFields = ['play_start', 'play_end', 'match_duration_minutes', 'starts_on', 'ends_on', 'day_durations', 'day_hours'];
        $before = $tournament->only($schedFields);

        $data = $request->validated();

        // Cover image upload (optional). Store on the default disk; replace any
        // previous image.
        if ($request->hasFile('cover_image')) {
            $disk = config('filesystems.default');
            if ($tournament->cover_image_path) {
                \Illuminate\Support\Facades\Storage::disk($disk)->delete($tournament->cover_image_path);
            }
            $data['cover_image_path'] = $request->file('cover_image')
                ->store('tournament-covers', $disk);
        }

        $dayDurations = collect($request->input('day_durations', []))
            ->filter(fn($v) => filled($v))          // drop empty inputs
            ->map(fn($v) => (int) $v)
            ->all();

        $data['day_durations'] = $dayDurations ?: null;   // null when none set

        // Per-day hours: keep only days where BOTH start and end are filled and
        // start < end; anything else falls back to the global window at runtime.
        $dayHours = collect($request->input('day_hours', []))
            ->map(fn($v) => [
                'start' => is_array($v) ? trim((string) ($v['start'] ?? '')) : '',
                'end'   => is_array($v) ? trim((string) ($v['end'] ?? '')) : '',
            ])
            ->filter(fn($v) => $v['start'] !== '' && $v['end'] !== '' && $v['start'] < $v['end'])
            ->all();

        $data['day_hours'] = $dayHours ?: null;   // null when none set

        // Tiebreak order: keep only valid criteria in the submitted order; null
        // when it equals the default (so the tournament just uses the default).
        $tbOrder = \App\Support\TiebreakCriteria::sanitize($request->input('tiebreak_order', []));
        $data['tiebreak_order'] = ($tbOrder === \App\Support\TiebreakCriteria::DEFAULT_ORDER)
            ? null
            : $tbOrder;

        $tournament->update([
            ...$data,
            'is_listed' => $request->boolean('is_listed'),
        ]);

        // Normalize before comparing so a save that doesn't touch scheduling
        // (e.g. only toggling "public") does NOT count as a change and won't
        // trigger the court resync.
        $norm = function ($f, $v) {
            if (in_array($f, ['play_start', 'play_end'], true)) {
                return $v ? substr((string) $v, 0, 5) : null;
            }
            if (in_array($f, ['starts_on', 'ends_on'], true)) {
                return $v ? \Illuminate\Carbon\Carbon::parse($v)->format('Y-m-d') : null;
            }
            if (in_array($f, ['day_durations', 'day_hours'], true)) {
                return empty($v) ? null : $v;
            }
            return $v;
        };
        $schedChanged = collect($schedFields)->contains(
            fn($f) => json_encode($norm($f, data_get($before, $f))) !== json_encode($norm($f, $tournament->{$f}))
        );

        $status = 'Torneo actualizado.';

        if ($schedChanged) {
            // Re-derive each court's availability from the new play window.
            $this->resyncCourtAvailability($tournament);

            // Unschedule only the matches that no longer fit the new grid.
            $moved = app(\App\Services\Tournament\SchedulingService::class)
                ->pruneInvalidSchedule($tournament);

            if ($moved > 0) {
                $status .= " {$moved} " . ($moved === 1 ? 'partido quedó' : 'partidos quedaron')
                    . " fuera del nuevo horario y se enviaron a «Sin programar».";
            }
        }

        $this->syncRankingSystems($request, $tournament);

        return redirect()
            ->route('tournaments.show', $tournament)
            ->with('status', $status);
    }

    /** Re-seed all courts' availability windows from current tournament settings. */
    private function resyncCourtAvailability(Tournament $tournament): void
    {
        // ADDITIVE: seed the default window only on days a court has NO window.
        // Never deletes existing (custom / imported) windows, so editing the
        // tournament no longer destroys per-court schedules. Shrinking the
        // window doesn't trim old windows here, but pruneInvalidSchedule() moves
        // off-grid matches to "unscheduled", so nothing invalid gets played.
        $tz = 'America/Mexico_City';
        $start = \Illuminate\Support\Str::of($tournament->play_start)->substr(0, 5);
        $end = \Illuminate\Support\Str::of($tournament->play_end)->substr(0, 5);

        $tournament->load('courts.availabilities');

        foreach ($tournament->courts as $court) {
            $daysWithWindows = $court->availabilities
                ->map(fn($a) => $a->starts_at->timezone($tz)->format('Y-m-d'))
                ->unique()
                ->flip();

            foreach ($tournament->playDays() as $day) {
                $d = $day->format('Y-m-d');
                if (isset($daysWithWindows[$d])) {
                    continue; // keep the custom schedule for this day
                }
                $court->availabilities()->create([
                    'starts_at' => \Carbon\Carbon::parse("$d $start", $tz),
                    'ends_at' => \Carbon\Carbon::parse("$d $end", $tz),
                ]);
            }
        }
    }

    public function destroy(Tournament $tournament)
    {
        $this->authorize('delete', $tournament);

        $tournament->delete();

        return redirect()
            ->route('tournaments.index')
            ->with('status', 'Torneo eliminado.');
    }

    private function syncRankingSystems(Request $request, Tournament $tournament): void
    {
        $requested = collect($request->input('ranking_system_ids', []))
            ->map(fn($id) => (int) $id)
            ->filter()
            ->unique();

        // Only allow systems this manager owns (created_by === manager id).
        $ownedIds = \App\Models\RankingSystem::query()
            ->where('created_by', $request->user()->id)
            ->whereIn('id', $requested)
            ->pluck('id');

        // Build the sync payload WITHOUT wiping finalized_at on rows that persist.
        // syncWithoutDetaching won't remove unchecked ones, so we compute the full
        // set explicitly: detach removed, keep existing pivots, attach new.
        $existing = $tournament->rankingSystems()
            ->pluck('ranking_system_tournament.finalized_at', 'ranking_systems.id');

        $payload = [];
        foreach ($ownedIds as $id) {
            // Keep prior finalized_at if the link already existed; else null.
            $payload[$id] = ['finalized_at' => $existing[$id] ?? null];
        }

        $tournament->rankingSystems()->sync($payload);
    }
}
