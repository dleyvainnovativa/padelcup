<?php

namespace App\Services\Tournament;

use App\Models\Court;
use App\Models\GameMatch;
use App\Models\Tournament;
use Carbon\Carbon;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;

/**
 * Scheduling: assigns matches to courts and times within court availability
 * windows, detecting two kinds of conflict:
 *
 *   1. Court overlap   — two matches on the same court at the same time.
 *   2. Player overlap  — a player (possibly in two pairs across categories)
 *                        scheduled in two places at once. This is the whole
 *                        reason player-level tracking exists.
 *
 * Times are CDMX. Default match duration is configurable per call.
 */
class SchedulingService
{
    /**
     * Check whether placing $match on $court at $startsAt for $duration would
     * conflict. Returns a list of human-readable conflict reasons (empty = ok).
     *
     * @return array<int, string>
     */
    public function conflictsFor(GameMatch $match, Court $court, Carbon $startsAt, int $duration): array
    {
        $endsAt = $startsAt->copy()->addMinutes($duration);
        $conflicts = [];

        // 1. Must fall within an availability window of the court.
        if (! $this->withinAvailability($court, $startsAt, $endsAt)) {
            $conflicts[] = 'Fuera del horario disponible de la cancha.';
        }

        // 2. Court overlap.
        if ($this->courtOverlap($court, $startsAt, $endsAt, $match->id)) {
            $conflicts[] = 'La cancha ya tiene un partido en ese horario.';
        }

        // 3. Player overlap (across ALL of this tournament's matches).
        // Identity is the NORMALIZED NAME, not player_id — the same person can be
        // a different Player row in each category (see playerKeys()).
        $playerKeys = $this->playerKeys($match);
        $clash = $this->playerOverlap($match, $playerKeys, $startsAt, $endsAt);
        if ($clash) {
            $conflicts[] = "Conflicto de jugador: {$clash} ya juega en ese horario.";
        }

        return $conflicts;
    }

    private function withinAvailability(Court $court, Carbon $startsAt, Carbon $endsAt): bool
    {
        return $court->availabilities()
            ->where('starts_at', '<=', $startsAt)
            ->where('ends_at', '>=', $endsAt)
            ->exists();
    }

    private function courtOverlap(Court $court, Carbon $startsAt, Carbon $endsAt, int $exceptMatchId): bool
    {
        return GameMatch::where('court_id', $court->id)
            ->where('id', '!=', $exceptMatchId)
            ->whereNotNull('starts_at')
            ->get()
            ->contains(fn($m) => $this->overlaps(
                $startsAt,
                $endsAt,
                $m->starts_at,
                $m->starts_at->copy()->addMinutes((int) ($m->duration_minutes ?: 60))
            ));
    }

    /**
     * Returns the name of a clashing player if any player in $playerKeys (normalized
     * names) is already scheduled in an overlapping match elsewhere in the tournament.
     * Cross-category safe: the same human in two categories has different player_ids
     * but the same normalized name.
     */
    private function playerOverlap(GameMatch $match, array $playerKeys, Carbon $startsAt, Carbon $endsAt): ?string
    {
        if (empty($playerKeys)) return null;

        $tournamentId = $match->category->tournament_id;

        // All scheduled matches in the tournament (other than this one).
        $scheduled = GameMatch::whereHas('category', fn($q) => $q->where('tournament_id', $tournamentId))
            ->where('id', '!=', $match->id)
            ->whereNotNull('starts_at')
            ->with(['pairA.player1', 'pairA.player2', 'pairB.player1', 'pairB.player2'])
            ->get();

        foreach ($scheduled as $other) {
            $otherEnds = $other->starts_at->copy()->addMinutes((int) ($other->duration_minutes ?: 60));
            if (! $this->overlaps($startsAt, $endsAt, $other->starts_at, $otherEnds)) {
                continue;
            }
            $shared = array_intersect($playerKeys, $this->playerKeys($other));
            if (! empty($shared)) {
                // Name the first clashing player.
                $key = reset($shared);
                $name = $this->playerNameByKey($other, $key) ?? 'Un jugador';
                return $name;
            }
        }

        return null;
    }



    private function overlaps(Carbon $aStart, Carbon $aEnd, Carbon $bStart, Carbon $bEnd): bool
    {
        return $aStart->lt($bEnd) && $bStart->lt($aEnd);
    }

    /**
     * After the tournament's scheduling settings change, unschedule ONLY the
     * matches that no longer fit the new grid — i.e. their start time now falls
     * outside [play_start, play_end), outside the tournament date range, or no
     * longer lands on a valid slot boundary. Still-valid placements are left
     * exactly where they are.
     *
     * @return int  number of matches moved back to "sin programar"
     */
    public function pruneInvalidSchedule(Tournament $tournament): int
    {
        $validDates = $tournament->playDays()->map->format('Y-m-d')->all();
        // Per-day slot map so pruning respects per-day hours (a match at 09:00 on
        // a day that now runs 17:00–23:00 is off-grid for that day).
        $daySlots = $tournament->daySlotMap(); // ['Y-m-d' => ['slots'=>[...], ...]]

        $matches = GameMatch::whereHas('category', fn($q) => $q->where('tournament_id', $tournament->id))
            ->whereNotNull('starts_at')
            ->get();

        $movedIds = [];

        foreach ($matches as $m) {
            $local = $m->starts_at->timezone('America/Mexico_City');
            $date = $local->format('Y-m-d');
            $time = $local->format('H:i');

            $outOfRange = ! in_array($date, $validDates, true);
            $slotsForDate = $daySlots[$date]['slots'] ?? [];
            $offGrid = ! in_array($time, $slotsForDate, true);

            if ($outOfRange || $offGrid) {
                $movedIds[] = $m->id;
            }
        }

        if (! empty($movedIds)) {
            GameMatch::whereIn('id', $movedIds)->update([
                'starts_at' => null,
                'court_id' => null,
            ]);
        }

        return count($movedIds);
    }

    /**
     * Phase-window auto-scheduler (in-memory). Places each unscheduled, ready
     * match within its PHASE WINDOW (groups / quarterfinal / semifinal / final…)
     * intersected with court availability, enforcing a per-pair rest gap
     * (min_rest_minutes) to prevent player collapse.
     *
     * If no phase windows are defined for the tournament, falls back to plain
     * court-availability scheduling (Step 1 behavior) so nothing breaks.
     *
     * @return array{scheduled: int, unplaced: int, by_phase: array<string,array{scheduled:int,unplaced:int}>}
     */
    public function autoSchedule(Tournament $tournament, Collection $courts, int $duration = 60, int $stepMinutes = 30): array
    {
        $stepSec = $stepMinutes * 60;
        $durSec = $duration * 60;
        $restSec = ((int) ($tournament->min_rest_minutes ?? 30)) * 60;

        // Court availability windows: [courtId => [[startTs, endTs], ...]],
        // CLIPPED to each day's play hours (day_hours override or global window),
        // so auto-scheduling never places a match before a day's first slot
        // (e.g. a day that runs 18:00–23:00 won't get 08:00 placements).
        $courtWindows = [];
        foreach ($courts as $court) {
            $clipped = [];
            foreach ($court->availabilities as $w) {
                foreach ($this->clipWindowToDayHours($tournament, $w->starts_at->timestamp, $w->ends_at->timestamp) as $seg) {
                    $clipped[] = $seg;
                }
            }
            usort($clipped, fn($a, $b) => $a[0] <=> $b[0]);
            $courtWindows[$court->id] = $clipped;
        }

        // Phase windows: [phaseKey => [[startTs, endTs], ...]].
        $phaseWindows = [];
        foreach ($tournament->phaseWindows as $pw) {
            $phaseWindows[$pw->phase][] = [$pw->starts_at->timestamp, $pw->ends_at->timestamp];
        }
        $hasPhases = ! empty($phaseWindows);

        // Player availability WINDOWS (manager-entered), keyed by normalized name:
        //   [ normalized_name => [ 'Y-m-d' => ['from'=>'HH:MM','until'=>'HH:MM'|null] ] ]
        // A match may only start at/after the LATEST "from" among its players on
        // that day, and must FINISH by the EARLIEST "until" among them ("all rules
        // must hold"). Days/players without a rule impose nothing.
        $availabilityMap = \App\Models\PlayerAvailability::windowsFor($tournament);

        // Per-day match duration: [ 'Y-m-d' => minutes ]. A day may override the
        // tournament default (e.g. the last day runs 90 min for SF/F). Used to
        // size each match by the day it lands on.
        $dayDurations = $tournament->dayDurationMap();
        $defaultDurSec = ((int) ($tournament->match_duration_minutes ?: $duration)) * 60;

        // Grid anchor: matches must align to the tournament's slot grid
        // (play_start stepping by match_duration_minutes) so they always land on
        // a visible row. We snap candidate start times to this grid.
        $anchorParse = Carbon::parse($tournament->play_start ?? '08:00', 'America/Mexico_City');
        $anchorMinOfDay = $anchorParse->hour * 60 + $anchorParse->minute;
        $gridStepSec = ((int) ($tournament->match_duration_minutes ?: $duration)) * 60;

        // Per-day grid anchor minute-of-day: each play day's own start (day_hours
        // override or global), so the auto-scheduler snaps to when the day opens.
        $dayAnchorMinutes = [];
        foreach ($tournament->playDays() as $d) {
            [$dStart] = $tournament->hoursForDay($d);
            [$h, $mi] = array_map('intval', explode(':', $dStart));
            $dayAnchorMinutes[$d->format('Y-m-d')] = $h * 60 + $mi;
        }

        // Seed occupancy from already-scheduled matches.
        $existing = GameMatch::whereHas('category', fn($q) => $q->where('tournament_id', $tournament->id))
            ->whereNotNull('starts_at')
            ->with(['pairA.player1', 'pairA.player2', 'pairB.player1', 'pairB.player2'])
            ->get();

        $courtBusy = [];
        $playerBusy = [];
        $endOf = []; // [matchId => endTs] — seeded with already-scheduled matches
        foreach ($existing as $m) {
            $start = $m->starts_at->timestamp;
            $end = $start + (((int) ($m->duration_minutes ?: $duration)) * 60);
            $endOf[$m->id] = $end;
            if ($m->court_id) $courtBusy[$m->court_id][] = [$start, $end];
            // Key busy-time by the player's IDENTITY (normalized name), so the same
            // human across categories collides with themselves.
            foreach ($this->playerKeys($m) as $pkey) {
                $playerBusy[$pkey][] = [$start, $end];
            }
        }

        // Unscheduled matches to place. With phase windows we INCLUDE placeholder
        // matches (pairs not yet known — Mexicano R2, bracket rounds fed by earlier
        // results) so the phase window can RESERVE their court/time ahead of time.
        // Without phase windows we keep the conservative behavior (ready matches
        // only), since there's no window to anchor a placeholder to.
        $query = GameMatch::whereHas('category', fn($q) => $q->where('tournament_id', $tournament->id))
            ->whereNull('starts_at')
            ->with(['group', 'category', 'pairA.player1', 'pairA.player2', 'pairB.player1', 'pairB.player2']);

        if ($hasPhases) {
            // Ready matches OR placeholders that will be fed later (feeders) OR
            // positional bracket matches with two real seed labels (e.g.
            // "Grupo G - 1 vs Grupo J - 1") — reserve their slot ahead of the
            // pairs binding. Genuine byes (a side = 'BYE') are excluded.
            $query->where(function ($q) {
                $q->where(fn($q) => $q->whereNotNull('pair_a_id')->whereNotNull('pair_b_id'))
                    ->orWhereNotNull('feeder_a_id')
                    ->orWhereNotNull('feeder_b_id')
                    ->orWhere(function ($q) {
                        $q->whereNotNull('seed_label_a')->whereNotNull('seed_label_b')
                            ->where('seed_label_a', '!=', 'BYE')
                            ->where('seed_label_b', '!=', 'BYE');
                    });
            });
        } else {
            $query->whereNotNull('pair_a_id')->whereNotNull('pair_b_id');
        }

        $matches = $query->get();

        // Order matches: phase → round (so dependencies hold), and WITHIN each
        // phase+round, INTERLEAVE categories so the early slots get a mix instead
        // of one category clustering at the front. This spreads each category
        // across the day. Round/feeder ordering is preserved because we never
        // mix matches of different rounds — only different categories of the same
        // round are interleaved.
        $order = \App\Support\SchedulePhase::keys();

        // 1) Bucket by (phase, round), keyed so buckets sort chronologically.
        $buckets = [];
        foreach ($matches as $m) {
            $bucketKey = sprintf('%02d-%03d', array_search($m->phaseKey(), $order, true), (int) ($m->round ?? 0));
            $buckets[$bucketKey][$m->category_id][] = $m;
        }
        ksort($buckets);

        // 2) Within each bucket, round-robin through categories (interleave).
        $ordered = [];
        foreach ($buckets as $byCategory) {
            // Each category's matches keep their own order; we rotate across
            // categories taking one at a time until all are drained.
            $queues = array_values($byCategory);
            $i = 0;
            while (! empty($queues)) {
                $idx = $i % count($queues);
                $ordered[] = array_shift($queues[$idx]);
                if (empty($queues[$idx])) {
                    array_splice($queues, $idx, 1);
                    // Don't advance $i: the next category shifted into this slot.
                } else {
                    $i++;
                }
            }
        }

        $matches = collect($ordered);

        $placements = []; // [matchId => [courtId, startTs]]
        $byPhase = [];     // [phaseKey => [scheduled, unplaced]]
        $availabilityBlocked = 0; // unplaced specifically due to player availability

        foreach ($matches as $match) {
            $phase = $match->phaseKey();
            $byPhase[$phase] ??= ['scheduled' => 0, 'unplaced' => 0];

            // Effective windows = court availability ∩ phase window (if defined).
            $allowed = $hasPhases ? ($phaseWindows[$phase] ?? []) : null;

            // A match cannot start before all its feeder matches have ENDED
            // (Mexicano R2 after its R1; bracket round after the round feeding it).
            // If a feeder isn't placed/known, we don't constrain on it.
            $earliest = 0;
            foreach ([$match->feeder_a_id, $match->feeder_b_id] as $fid) {
                if ($fid && isset($endOf[$fid])) {
                    $earliest = max($earliest, $endOf[$fid]);
                }
            }

            $playerKeys = $this->playerKeys($match);

            // Per-day availability WINDOW for THIS match: for each restricted day,
            // ['from'=>ts, 'until'=>ts|null] — the binding "from" is the latest
            // among players, the binding "until" is the earliest among them (all
            // rules hold). Empty when no participating player has a rule.
            $availWindows = $this->availabilityWindows($match, $availabilityMap);

            $slot = $this->findSlotInMemory(
                $courts,
                $courtWindows,
                $courtBusy,
                $playerBusy,
                $playerKeys,
                $defaultDurSec,
                $stepSec,
                $restSec,
                $allowed,
                $anchorMinOfDay,
                $gridStepSec,
                $earliest,
                $availWindows,
                $dayDurations,
                $dayAnchorMinutes,
            );

            if ($slot) {
                [$courtId, $startTs, $slotDurSec] = $slot;
                $endTs = $startTs + $slotDurSec;
                $courtBusy[$courtId][] = [$startTs, $endTs];
                foreach ($playerKeys as $pkey) {
                    $playerBusy[$pkey][] = [$startTs, $endTs];
                }
                $placements[$match->id] = [$courtId, $startTs, intdiv($slotDurSec, 60)];
                $endOf[$match->id] = $endTs;
                $byPhase[$phase]['scheduled']++;
            } else {
                $byPhase[$phase]['unplaced']++;
                // Distinguish "blocked by availability" from "didn't fit": if the
                // match has availability windows AND would have fit ignoring them,
                // attribute it to availability for clearer reporting.
                if (! empty($availWindows)) {
                    $slotIgnoringAvail = $this->findSlotInMemory(
                        $courts,
                        $courtWindows,
                        $courtBusy,
                        $playerBusy,
                        $playerKeys,
                        $defaultDurSec,
                        $stepSec,
                        $restSec,
                        $allowed,
                        $anchorMinOfDay,
                        $gridStepSec,
                        $earliest,
                        [],
                        $dayDurations,
                        $dayAnchorMinutes,
                    );
                    if ($slotIgnoringAvail) {
                        $byPhase[$phase]['unplaced_availability'] =
                            ($byPhase[$phase]['unplaced_availability'] ?? 0) + 1;
                        $availabilityBlocked++;
                    }
                }
            }
        }

        DB::transaction(function () use ($placements) {
            foreach ($placements as $matchId => [$courtId, $startTs, $durMin]) {
                GameMatch::where('id', $matchId)->update([
                    'court_id' => $courtId,
                    'starts_at' => Carbon::createFromTimestamp($startTs, 'America/Mexico_City'),
                    'duration_minutes' => $durMin,
                ]);
            }
        });

        return [
            'scheduled' => count($placements),
            'unplaced' => $matches->count() - count($placements),
            'availability_blocked' => $availabilityBlocked,
            'by_phase' => $byPhase,
        ];
    }

    /**
     * Earliest conflict-free slot using only in-memory arrays.
     *
     * @param  array|null  $allowed  Phase windows [[startTs,endTs],...] to
     *         intersect with court availability; null = no phase restriction.
     * @return array{0:int,1:int}|null  [courtId, startTs]
     */
    private function findSlotInMemory(
        Collection $courts,
        array $courtWindows,
        array $courtBusy,
        array $playerBusy,
        array $playerKeys,
        int $durSec,
        int $stepSec,
        int $restSec = 0,
        ?array $allowed = null,
        int $anchorMinOfDay = 480,
        int $gridStepSec = 0,
        int $earliestStart = 0,
        array $availWindows = [],
        array $dayDurations = [],
        array $dayAnchorMinutes = [],
    ): ?array {
        $best = null;

        foreach ($courts as $court) {
            $cid = $court->id;
            foreach ($courtWindows[$cid] ?? [] as [$wStart, $wEnd]) {
                // Clip the court window to the allowed phase windows.
                $segments = $allowed === null
                    ? [[$wStart, $wEnd]]
                    : $this->clipToAllowed($wStart, $wEnd, $allowed);

                foreach ($segments as [$segStart, $segEnd]) {
                    // Floor the segment by the earliest allowed start (feeder
                    // matches must finish first).
                    $segStart = max($segStart, $earliestStart);
                    if ($segStart >= $segEnd) continue;

                    // Snap the segment start UP to the next grid-aligned slot so
                    // placements always land on a visible row. Use THIS DAY's step
                    // (a court segment is within one day), so the snap matches the
                    // per-day grid the calendar draws (e.g. 90-min day → 08:00,
                    // 09:30, 11:00…), not the global default step.
                    $segDay = Carbon::createFromTimestamp($segStart, 'America/Mexico_City')->format('Y-m-d');
                    $segStepSec = isset($dayDurations[$segDay]) ? $dayDurations[$segDay] * 60 : $gridStepSec;

                    // Per-day grid anchor: the day's own start minute (day_hours
                    // override or global), so the grid aligns to when the day
                    // actually opens (e.g. 18:00), not the global 08:00.
                    $segAnchorMin = $dayAnchorMinutes[$segDay] ?? $anchorMinOfDay;

                    $start = $segStepSec > 0
                        ? $this->snapToGrid($segStart, $segAnchorMin, $segStepSec)
                        : $segStart;

                    // Duration depends on the DAY of the candidate slot (the last
                    // day may run longer). Look it up per candidate; the step also
                    // follows the day's duration so rows stay aligned within a day.
                    for ($ts = $start; $ts < $segEnd;) {
                        $day = Carbon::createFromTimestamp($ts, 'America/Mexico_City')->format('Y-m-d');
                        $dayDurSec = isset($dayDurations[$day]) ? $dayDurations[$day] * 60 : $durSec;
                        $end = $ts + $dayDurSec;
                        $stepThis = $dayDurSec > 0 ? $dayDurSec : $stepSec;

                        // Must fit inside the court/phase segment.
                        if ($end > $segEnd) break;

                        if (! empty($availWindows) && isset($availWindows[$day]) && ! empty($availWindows[$day]['off'])) {
                            // Whole day blocked for a participating player — jump past it.
                            $ts += $stepThis;
                            continue;
                        }
                        // Player availability window on this day: start >= from,
                        // and end <= until (match must FINISH by "until").
                        if (! empty($availWindows) && isset($availWindows[$day])) {
                            $win = $availWindows[$day];
                            if (isset($win['from']) && $win['from'] !== null && $ts < $win['from']) {
                                $ts += $stepThis;
                                continue;
                            }
                            if (isset($win['until']) && $win['until'] !== null && $end > $win['until']) {
                                $ts += $stepThis;
                                continue;
                            }
                        }

                        if ($this->intervalHits($courtBusy[$cid] ?? [], $ts, $end)) {
                            $ts += $stepThis;
                            continue;
                        }

                        $clash = false;
                        foreach ($playerKeys as $pkey) {
                            if ($this->intervalHits($playerBusy[$pkey] ?? [], $ts, $end, $restSec)) {
                                $clash = true;
                                break;
                            }
                        }
                        if ($clash) {
                            $ts += $stepThis;
                            continue;
                        }

                        if ($best === null || $ts < $best[1]) $best = [$cid, $ts, $dayDurSec];
                        break 2;
                    }
                }
            }
        }

        return $best;
    }

    /**
     * Clip a [startTs, endTs] window to each day's play hours (day_hours override
     * or the global play_start/play_end). A window spanning several days is split
     * into one clipped segment per day. Returns [[segStart, segEnd], ...].
     */
    private function clipWindowToDayHours(Tournament $tournament, int $startTs, int $endTs): array
    {
        if ($endTs <= $startTs) return [];

        $segments = [];
        $tz = 'America/Mexico_City';
        $cursorDay = Carbon::createFromTimestamp($startTs, $tz)->startOfDay();
        $lastDay = Carbon::createFromTimestamp($endTs, $tz)->startOfDay();

        while ($cursorDay->lte($lastDay)) {
            [$dStart, $dEnd] = $tournament->hoursForDay($cursorDay);
            [$sh, $sm] = array_map('intval', explode(':', $dStart));
            [$eh, $em] = array_map('intval', explode(':', $dEnd));

            $dayOpen = $cursorDay->timestamp + ($sh * 60 + $sm) * 60;
            $dayClose = $cursorDay->timestamp + ($eh * 60 + $em) * 60;

            // Intersect the court window with this day's open hours.
            $segStart = max($startTs, $dayOpen);
            $segEnd = min($endTs, $dayClose);
            if ($segStart < $segEnd) {
                $segments[] = [$segStart, $segEnd];
            }

            $cursorDay = $cursorDay->copy()->addDay();
        }

        return $segments;
    }

    /**
     * Snap a timestamp UP to the next time that aligns with the slot grid
     * (a day's $anchorMinOfDay, stepping by $gridStepSec). Keeps placements on
     * the visible grid rows.
     */
    private function snapToGrid(int $ts, int $anchorMinOfDay, int $gridStepSec): int
    {
        $day = Carbon::createFromTimestamp($ts, 'America/Mexico_City')->startOfDay();
        $anchorTs = $day->timestamp + $anchorMinOfDay * 60;
        if ($ts <= $anchorTs) return $anchorTs;
        $elapsed = $ts - $anchorTs;
        $steps = (int) ceil($elapsed / $gridStepSec);
        return $anchorTs + $steps * $gridStepSec;
    }

    /**
     * Intersect a [start,end] window with a set of allowed windows, returning
     * the overlapping sub-segments (sorted by start).
     */
    private function clipToAllowed(int $start, int $end, array $allowed): array
    {
        $out = [];
        foreach ($allowed as [$aStart, $aEnd]) {
            $s = max($start, $aStart);
            $e = min($end, $aEnd);
            if ($s < $e) $out[] = [$s, $e];
        }
        usort($out, fn($a, $b) => $a[0] <=> $b[0]);
        return $out;
    }

    /**
     * True if [start,end) overlaps any interval in $list. Each interval may be
     * padded by $pad seconds on both sides (used for the per-pair rest gap).
     */
    private function intervalHits(array $list, int $start, int $end, int $pad = 0): bool
    {
        foreach ($list as [$s, $e]) {
            if ($start < ($e + $pad) && ($s - $pad) < $end) return true;
        }
        return false;
    }

    /**
     * Post-resolution conflict check: find players booked in two (or more)
     * SCHEDULED matches whose times overlap (hard conflict) or fall within the
     * rest gap (soft warning). Only considers matches with KNOWN players — the
     * cross-category collapse that placeholder scheduling can't prevent up front.
     *
     * @return array<int,array{player:string, severity:string, matches:array}>
     */
    public function detectConflicts(Tournament $tournament): array
    {
        $restSec = ((int) ($tournament->min_rest_minutes ?? 30)) * 60;

        $matches = GameMatch::whereHas('category', fn($q) => $q->where('tournament_id', $tournament->id))
            ->whereNotNull('starts_at')
            ->whereNotNull('pair_a_id')->whereNotNull('pair_b_id')
            ->with(['category', 'group', 'court', 'pairA.player1', 'pairA.player2', 'pairB.player1', 'pairB.player2'])
            ->get();

        // [normalizedName => [ ['match'=>m,'start'=>ts,'end'=>ts], ... ]]
        // Keyed by IDENTITY (normalized name) so the same human playing in two
        // categories (different Player rows) is detected as one person.
        $byPlayer = [];
        foreach ($matches as $m) {
            $start = $m->starts_at->timestamp;
            $end = $start + (((int) ($m->duration_minutes ?: 60)) * 60);
            foreach ($this->playerKeys($m) as $pkey) {
                $byPlayer[$pkey][] = ['match' => $m, 'start' => $start, 'end' => $end];
            }
        }

        $conflicts = [];
        foreach ($byPlayer as $pkey => $entries) {
            if (count($entries) < 2) continue;
            usort($entries, fn($a, $b) => $a['start'] <=> $b['start']);

            for ($i = 0; $i < count($entries) - 1; $i++) {
                for ($j = $i + 1; $j < count($entries); $j++) {
                    $a = $entries[$i];
                    $b = $entries[$j];

                    $hardOverlap = $a['start'] < $b['end'] && $b['start'] < $a['end'];
                    $restViolation = ! $hardOverlap
                        && $b['start'] >= $a['end']
                        && ($b['start'] - $a['end'] < $restSec);

                    if (! $hardOverlap && ! $restViolation) continue;

                    $conflicts[] = [
                        'player' => $this->playerNameByKey($a['match'], $pkey) ?? 'Jugador',
                        'severity' => $hardOverlap ? 'overlap' : 'rest',
                        'matches' => [
                            $this->matchInfo($a['match']),
                            $this->matchInfo($b['match']),
                        ],
                    ];
                }
            }
        }

        // De-dupe (same player + same two matches).
        $seen = [];
        $unique = [];
        foreach ($conflicts as $c) {
            $key = $c['player'] . '|' . implode('|', array_map(fn($x) => $x['label'] . $x['time'], $c['matches']));
            if (isset($seen[$key])) continue;
            $seen[$key] = true;
            $unique[] = $c;
        }

        // Hard overlaps first.
        usort($unique, fn($a, $b) => ($a['severity'] === 'overlap' ? 0 : 1) <=> ($b['severity'] === 'overlap' ? 0 : 1));

        return $unique;
    }

    /**
     * Per-day availability WINDOW for a match: for each day one or more of its
     * players restricts, the binding window is ['from'=>ts, 'until'=>ts|null] —
     * "from" is the LATEST start among players (all must be available), "until"
     * is the EARLIEST end among players (all must be gone by then). A day where
     * no player sets an "until" has 'until'=>null (no upper bound).
     *
     * Players matched by NORMALIZED NAME. Placeholder matches (no known pairs) or
     * players with no rules → empty (no constraint).
     *
     * @param  array<string, array<string, array{from:string, until:?string}>>  $availabilityMap
     * @return array<string, array{from:int, until:?int}>
     */
    private function availabilityWindows(GameMatch $match, array $availabilityMap): array
    {
        if (empty($availabilityMap)) return [];

        $names = [];
        foreach ([$match->pairA, $match->pairB] as $pair) {
            if (! $pair) continue;
            foreach ([$pair->player1, $pair->player2] as $p) {
                if ($p && filled($p->name)) {
                    $names[] = \App\Models\Player::normalize($p->name);
                }
            }
        }
        if (empty($names)) return [];

        // Per day: latest "from" (string compare ok, zero-padded) and earliest
        // "until" among the participating players who restrict that day.
        $fromHHMM = [];
        $untilHHMM = [];
        $offDays = [];              // 'Y-m-d' => true
        foreach ($names as $key) {
            foreach ($availabilityMap[$key] ?? [] as $day => $win) {
                if (is_array($win) && ! empty($win['off'])) {
                    $offDays[$day] = true;
                    continue;
                }
                $from = is_array($win) ? ($win['from'] ?? null) : $win;
                $until = is_array($win) ? ($win['until'] ?? null) : null;

                if ($from !== null) {
                    if (! isset($fromHHMM[$day]) || $from > $fromHHMM[$day]) $fromHHMM[$day] = $from;
                }
                if ($until !== null) {
                    if (! isset($untilHHMM[$day]) || $until < $untilHHMM[$day]) $untilHHMM[$day] = $until;
                }
            }
        }

        $days = array_unique(array_merge(array_keys($fromHHMM), array_keys($untilHHMM), array_keys($offDays)));
        if (empty($days)) return [];

        $out = [];
        foreach ($days as $day) {
            $out[$day] = [
                'from' => isset($fromHHMM[$day])
                    ? Carbon::parse("$day {$fromHHMM[$day]}", 'America/Mexico_City')->timestamp
                    : 0,
                'until' => isset($untilHHMM[$day])
                    ? Carbon::parse("$day {$untilHHMM[$day]}", 'America/Mexico_City')->timestamp
                    : null,
            ];
        }
        // Off days override everything for that day.
        foreach ($offDays as $day => $_) {
            $out[$day] = ['off' => true, 'from' => 0, 'until' => null];
        }
        return $out;
    }

    /** Resolve a player's display name from a match's pairs. */
    /**
     * The IDENTITY keys of a match's players: normalized names, not player ids.
     *
     * The same human is often a SEPARATE Player row per category (see
     * RegistrationService::resolvePlayer — a player with no email/phone gets a
     * new row each time they're imported). Comparing raw player_ids therefore
     * MISSES cross-category clashes: "Ana García" in 5ta and "Ana García" in 6ta
     * are different ids but the same person, who cannot be on two courts at once.
     *
     * Availability rules already key on normalized_name for exactly this reason;
     * conflict detection must too.
     *
     * @return array<int,string>
     */
    private function playerKeys(GameMatch $match): array
    {
        $keys = [];
        foreach ([$match->pairA, $match->pairB] as $pair) {
            if (! $pair) continue;
            foreach ([$pair->player1, $pair->player2] as $p) {
                if ($p && filled($p->name)) {
                    $keys[] = \App\Models\Player::normalize($p->name);
                }
            }
        }
        return array_values(array_unique($keys));
    }

    /** Name of the player matching a normalized key, for conflict messages. */
    private function playerNameByKey(GameMatch $match, string $key): ?string
    {
        foreach ([$match->pairA, $match->pairB] as $pair) {
            if (! $pair) continue;
            foreach ([$pair->player1, $pair->player2] as $p) {
                if ($p && filled($p->name) && \App\Models\Player::normalize($p->name) === $key) {
                    return $p->name;
                }
            }
        }
        return null;
    }

    private function playerName(GameMatch $match, int $playerId): ?string
    {
        foreach ([$match->pairA, $match->pairB] as $pair) {
            if (! $pair) continue;
            foreach ([$pair->player1, $pair->player2] as $p) {
                if ($p && $p->id === $playerId) {
                    return $p->name;
                }
            }
        }
        return null;
    }

    /** Compact match descriptor for the conflict report. */
    private function matchInfo(GameMatch $match): array
    {
        return [
            'label' => $match->contextLabel(),
            'court' => $match->court?->name,
            'time' => $match->starts_at?->timezone('America/Mexico_City')->translatedFormat('D d M · H:i'),
        ];
    }
    public function restWarningsFor(GameMatch $match, Carbon $startsAt, int $duration): array
    {
        $tournament = $match->category->tournament;
        $restMin = (int) ($tournament->min_rest_minutes ?? 30);
        if ($restMin <= 0) {
            return []; // rest gap disabled for this tournament
        }
        $restSec = $restMin * 60;

        $playerKeys = $this->playerKeys($match);
        if (empty($playerKeys)) {
            return []; // unbound/placeholder match — no known players to protect
        }

        $thisStart = $startsAt->timestamp;
        $thisEnd   = $thisStart + ($duration * 60);

        $tournamentId = $match->category->tournament_id;

        // Other scheduled, player-bound matches in the tournament.
        $scheduled = GameMatch::whereHas('category', fn($q) => $q->where('tournament_id', $tournamentId))
            ->where('id', '!=', $match->id)
            ->whereNotNull('starts_at')
            ->with(['pairA.player1', 'pairA.player2', 'pairB.player1', 'pairB.player2'])
            ->get();

        // Collect offenders keyed by normalized-name so each player is named once,
        // with the closest conflicting match cited.
        $offenders = []; // pkey => ['name' => string, 'gapMin' => int, 'other' => GameMatch]

        foreach ($scheduled as $other) {
            $shared = array_intersect($playerKeys, $this->playerKeys($other));
            if (empty($shared)) {
                continue;
            }

            $otherStart = $other->starts_at->timestamp;
            $otherEnd   = $otherStart + (((int) ($other->duration_minutes ?: 60)) * 60);

            // Hard overlap is handled by conflictsFor(); skip it here so we don't
            // double-report. We only care about the non-overlapping "too close" gap.
            $hardOverlap = $thisStart < $otherEnd && $otherStart < $thisEnd;
            if ($hardOverlap) {
                continue;
            }

            // Gap between the two matches, whichever order they fall in.
            if ($otherStart >= $thisEnd) {
                $gapSec = $otherStart - $thisEnd;       // other is AFTER this
            } else {
                $gapSec = $thisStart - $otherEnd;       // other is BEFORE this
            }

            if ($gapSec < $restSec) {
                foreach ($shared as $pkey) {
                    $gapMin = intdiv($gapSec, 60);
                    // Keep the CLOSEST conflicting match per player.
                    if (! isset($offenders[$pkey]) || $gapMin < $offenders[$pkey]['gapMin']) {
                        $offenders[$pkey] = [
                            'name'   => $this->playerNameByKey($other, $pkey)
                                ?? $this->playerNameByKey($match, $pkey)
                                ?? 'Un jugador',
                            'gapMin' => $gapMin,
                            'other'  => $other,
                        ];
                    }
                }
            }
        }

        // Build messages.
        $messages = [];
        foreach ($offenders as $o) {
            $messages[] = "Sin descanso: {$o['name']} tendría solo {$o['gapMin']} min "
                . "entre partidos (mínimo {$restMin} min).";
        }

        return $messages;
    }
}
