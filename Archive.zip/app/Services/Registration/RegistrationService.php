<?php

namespace App\Services\Registration;

use App\Enums\PaymentStatus;
use App\Enums\RegistrationSource;
use App\Enums\RegistrationStatus;
use App\Models\Category;
use App\Models\Pair;
use App\Models\Player;
use App\Models\Registration;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

/**
 * Registration logic. Covers the MANAGER path:
 *   - manager-created pairs are confirmed immediately
 *   - payment is tracked separately (pay-later allowed)
 *   - capacity (max_pairs) is enforced as a hard block
 *
 * Singles: in a singles category the "pair" is a single player. The manager
 * form omits player 2, so player2 arrives empty and the pair is created solo
 * with is_singles = true. The competition engine treats it like any other
 * unit (player2_id = null is already tolerated everywhere).
 */
class RegistrationService
{
    /**
     * Create a manager pair in a category from player definitions.
     *
     * Each player def: ['name' => ..., 'email' => ?, 'phone' => ?, 'player_id' => ?]
     * If player_id is given, that existing Player is used; otherwise one is created.
     *
     * For a singles category, $player2 is ignored (no second player is created).
     *
     * @throws ValidationException when the category is full.
     */
    public function createManagerPair(
        Category $category,
        array $player1,
        array $player2,
        User $manager,
        bool $markPaid = false,
    ): Pair {
        $this->assertHasCapacity($category);

        $isSingles = $category->isSingles();

        return DB::transaction(function () use ($category, $player1, $player2, $manager, $markPaid, $isSingles) {
            $p1 = $this->resolvePlayer($player1, $manager);

            // Singles: no second player. Doubles: resolve as before.
            $p2 = $isSingles ? null : $this->resolvePlayer($player2, $manager);

            $pair = Pair::create([
                'category_id' => $category->id,
                'is_singles' => $isSingles,
                'player1_id' => $p1->id,
                'player2_id' => $p2?->id,
            ]);

            Registration::create([
                'pair_id' => $pair->id,
                'category_id' => $category->id,
                'source' => RegistrationSource::Manager,
                'status' => RegistrationStatus::Confirmed, // manager path: confirmed immediately
                'payment_status' => $markPaid ? PaymentStatus::Paid : PaymentStatus::Unpaid,
                'terms_accepted_at' => now(),
                'terms_version' => config('app.terms_version', '1.0'),
            ]);

            return $pair->load('player1', 'player2', 'registration');
        });
    }

    /** Public entry to resolve-or-create a player (id, or dedup by email/phone,
     *  else create). Used by player substitution too. */
    public function resolveOrCreatePlayer(array $def, User $manager): Player
    {
        return $this->resolvePlayer($def, $manager);
    }

    /** Resolve an existing player by id, or reuse one matched by email/phone
     *  (manager-owned), or create a new one. */
    private function resolvePlayer(array $def, User $manager): Player
    {
        if (! empty($def['player_id'])) {
            return Player::findOrFail($def['player_id']);
        }

        // Reuse an existing player created by THIS manager when a contact field
        // matches (email or phone). A bare name is never enough to dedup — two
        // different people can share a name — so we only match on contact info.
        $email = $def['email'] ?? null;
        $phone = $def['phone'] ?? null;

        if (filled($email) || filled($phone)) {
            $existing = Player::query()
                ->where('created_by', $manager->id)
                ->where(function ($q) use ($email, $phone) {
                    if (filled($email)) $q->orWhere('email', $email);
                    if (filled($phone)) $q->orWhere('phone', $phone);
                })
                ->first();

            if ($existing) {
                // Backfill a missing contact field if this row supplies it.
                $patch = [];
                if (blank($existing->email) && filled($email)) $patch['email'] = $email;
                if (blank($existing->phone) && filled($phone)) $patch['phone'] = $phone;
                if ($patch) $existing->update($patch);

                return $existing;
            }
        }

        return Player::create([
            'name' => $def['name'],
            'email' => $email,
            'phone' => $phone,
            'created_by' => $manager->id,
        ]);
    }

    /** Hard capacity check. min_pairs is a soft warning handled in the UI. */
    public function assertHasCapacity(Category $category): void
    {
        if ($category->isFull()) {
            throw ValidationException::withMessages([
                'category' => "La categoría «{$category->name}» está llena ({$category->max_pairs} parejas).",
            ]);
        }
    }

    /** Mark a registration's payment status (manager pay-later tracking). */
    public function setPaymentStatus(Registration $registration, PaymentStatus $status): Registration
    {
        $registration->update(['payment_status' => $status]);

        return $registration;
    }

    /** Remove a pair (and its registration) before the tournament locks. */
    public function removePair(Pair $pair): void
    {
        DB::transaction(function () use ($pair) {
            $pair->registration?->delete();
            $pair->delete();
        });
    }
}
